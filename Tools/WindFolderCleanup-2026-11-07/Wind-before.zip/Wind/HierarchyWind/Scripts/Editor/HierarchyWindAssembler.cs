using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace WindPrototype.HierarchyExperiment.Editor
{
    public static class HierarchyWindAssembler
    {
        [Serializable] sealed class Record { public Vector3 pivot; public Vector3 tip; public float weight; }
        [Serializable] sealed class Source { public Vector3[] vertices; public int[] triangles; public Record[] records; }

        static string Root
        {
            get
            {
                string[] guids = AssetDatabase.FindAssets("HierarchyWindAssembler t:MonoScript");
                if (guids.Length != 1) throw new InvalidOperationException("Expected one HierarchyWindAssembler script.");
                return Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(
                    AssetDatabase.GUIDToAssetPath(guids[0])))).Replace('\\','/');
            }
        }

        [MenuItem("Tools/Wind/Hierarchy Experiment/1 Generate Assets")]
        public static void Generate()
        {
            string root = Root;
            string output = root + "/GeneratedColorTexture";
            if (!AssetDatabase.IsValidFolder(output)) AssetDatabase.CreateFolder(root,"GeneratedColorTexture");
            Source source = JsonUtility.FromJson<Source>(File.ReadAllText(root+"/Models/HierarchyWindTree.json"));
            if (source.vertices == null || source.records == null || source.vertices.Length != source.records.Length)
                throw new InvalidDataException("Missing or inconsistent vertex records.");
            Bounds bakeBounds = new Bounds(source.vertices[0],Vector3.zero);
            foreach (Vector3 vertex in source.vertices) bakeBounds.Encapsulate(vertex);
            Vector3 bakeSize = bakeBounds.size;
            bakeSize = new Vector3(Mathf.Max(bakeSize.x,0.0001f),Mathf.Max(bakeSize.y,0.0001f),Mathf.Max(bakeSize.z,0.0001f));
            string meshPath = output+"/HierarchyWindTree.asset";
            string texturePath = output+"/HierarchyWindData.asset";
            string materialPath = output+"/HierarchyWind.mat";
            // Preserve existing generated assets/references; do not silently overwrite artist edits.
            Mesh mesh = AssetDatabase.LoadAssetAtPath<Mesh>(meshPath);
            if (!mesh)
            {
                mesh = new Mesh { name = "HierarchyWindTree_" + source.vertices.Length + "Vertices" };
                mesh.vertices = source.vertices;
                mesh.triangles = source.triangles;
                var colors = new Color[source.vertices.Length];
                for (int i=0;i<colors.Length;i++)
                {
                    Vector3 p = source.records[i].pivot-bakeBounds.min;
                    colors[i]=new Color(p.x/bakeSize.x,p.y/bakeSize.y,p.z/bakeSize.z,source.records[i].weight);
                }
                mesh.colors=colors;
                mesh.RecalculateNormals();
                mesh.RecalculateBounds();
                AssetDatabase.CreateAsset(mesh,meshPath);
            }
            Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(texturePath);
            if (!texture)
            {
                texture = new Texture2D(1,source.records.Length,TextureFormat.RGBAHalf,false,true)
                    { name="HierarchyWindData", filterMode=FilterMode.Point, wrapMode=TextureWrapMode.Clamp, anisoLevel=0 };
                for (int i=0;i<source.records.Length;i++)
                {
                    Record r=source.records[i];
                    Vector3 tip = r.tip - bakeBounds.min;
                    texture.SetPixel(0,i,new Color(tip.x/bakeSize.x,tip.y/bakeSize.y,tip.z/bakeSize.z,0));
                }
                texture.Apply(false,false);
                AssetDatabase.CreateAsset(texture,texturePath);
            }
            Material material = AssetDatabase.LoadAssetAtPath<Material>(materialPath);
            if (!material)
            {
                Shader shader = Shader.Find("Wind/Experiments/HierarchyWind");
                if (!shader) throw new InvalidOperationException("HierarchyWind shader has not imported yet.");
                material = new Material(shader) { name="HierarchyWind", enableInstancing=true };
                material.SetTexture("_HWData",texture);
                material.SetVector("_HWBakeMin",bakeBounds.min);
                material.SetVector("_HWBakeSize",bakeSize);
                AssetDatabase.CreateAsset(material,materialPath);
            }
            string prefabPath=output+"/HierarchyWindTree.prefab";
            if (!AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath))
            {
                var obj=new GameObject("HierarchyWindTree");
                try
                {
                    obj.AddComponent<MeshFilter>().sharedMesh=mesh;
                    obj.AddComponent<MeshRenderer>().sharedMaterial=material;
                    obj.AddComponent<HierarchyWindResponse>();
                    PrefabUtility.SaveAsPrefabAsset(obj,prefabPath);
                }
                finally { UnityEngine.Object.DestroyImmediate(obj); }
            }
            AssetDatabase.SaveAssets();
            EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath));
        }

        [MenuItem("Tools/Wind/Hierarchy Experiment/2 Add Demo To Current Scene")]
        public static void AddDemo()
        {
            Generate();
            var group=new GameObject("HierarchyWindExperiment");
            Undo.RegisterCreatedObjectUndo(group,"Add hierarchy wind demo");
            HierarchyWindField field=group.AddComponent<HierarchyWindField>();
            var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(Root+"/GeneratedColorTexture/HierarchyWindTree.prefab");
            for (int i=0;i<3;i++)
            {
                var tree=(GameObject)PrefabUtility.InstantiatePrefab(prefab,group.transform);
                Undo.RegisterCreatedObjectUndo(tree,"Add hierarchy wind tree");
                tree.transform.localPosition=new Vector3((i-1)*3,0,0);
                tree.GetComponent<HierarchyWindResponse>().field=field;
            }
            Selection.activeGameObject=group;
            // Deliberately leave scene save and camera/lighting setup to the user.
        }
    }
}
